export interface CompareData {
  age: number;
  height: number;
  income: number;
}
