const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/moviedb');

const Movie = mongoose.model('Movie', {
  id: Number,
  title: String,
  year: Number,
});

module.exports = {
  getAll() {
    return Movie.find({});
  },
  get(id) {
    return Movie.findOne({ id });
  },
  delete(id) {
    return this.get(id).then(movie => movie.remove());
  },
  save(movie) {
    if (!movie.id) {
      const newMovie = new Movie(movie);
      newMovie.id = Date.now();
      return newMovie.save();
    } else {
      return this.get(parseInt(movie.id, 10)).then(existingMovie => {
        existingMovie.title = movie.title;
        existingMovie.year = movie.year;
        return existingMovie.save();
      });
    }
  },
};
