const MongoClient = require('mongodb').MongoClient;

function connect() {
  return new Promise((resolve, reject) => {
    const url = 'mongodb://localhost:27017';
    MongoClient.connect(url, function(err, client) {
      const db = client.db('moviedb');
      const collection = db.collection('Movie');
      resolve({ collection, client });
    });
  });
}

function insert(movie) {
  movie.id = Date.now();
  return connect().then(({ collection, client }) => {
    return new Promise((resolve, reject) => {
      collection.insert(movie, { safe: true }, (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
        client.close();
      });
    });
  });
}

function get(query = {}) {
  return connect().then(({ collection, client }) => {
    return new Promise((resolve, reject) => {
      collection.find(query).toArray((error, docs) => {
        if (error) {
          reject(error);
        } else {
          resolve(docs);
        }
        client.close();
      });
    });
  });
}

function update(movie) {
  return connect().then(({ collection, client }) => {
    return new Promise((resolve, reject) => {
      collection.update(
        { id: movie.id },
        { $set: movie },
        { safe: true },
        function(error) {
          if (error) {
            reject(error);
          } else {
            resolve();
          }
          client.close();
        },
      );
    });
  });
}

module.exports = {
  getAll: get(),
  get(id) {
    return get({ id });
  },
  save(movie) {
    if (!movie.id) {
      return insert(movie);
    }
    return update(movie);
  },
};
