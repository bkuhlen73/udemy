const MongoClient = require('mongodb').MongoClient;

function connect() {
  return new Promise((resolve, reject) => {
    const url = 'mongodb://localhost:27017';
    MongoClient.connect(
      url,
      (err, client) => {
        const db = client.db('moviedb');
        const collection = db.collection('Movie');
        resolve({ collection, client });
      },
    );
  });
}

function insert(movie) {
  movie.id = Date.now();
  return connect().then(({ collection, client }) => {
    return new Promise((resolve, reject) => {
      collection.insert(movie, { safe: true }, (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
        client.close();
      });
    });
  });
}

function getAll() {
  return Promise.resolve([]);
}

module.exports = {
  getAll,
  save(movie) {
    if (!movie.id) {
      return insert(movie);
    }
  },
};
