const redis = require('redis');
const client = redis.createClient();

client.on('error', error => console.error(error));

module.exports = {
  getAll() {
    return Movies.findAll();
  },
  get(id) {
    return Movies.findById(id);
  },
  delete(id) {
    return Movies.destroy({ where: { id } });
  },
  save(movie) {
    return Movies.upsert(movie);
  },
};
