const redis = require('redis');
const client = redis.createClient();

client.on('error', error => console.error(error));

function save(movie) {
  return new Promise((resolve, reject) => {
    if (!movie.id) {
      movie.id = Date.now();
    }
    client.set(movie.id, JSON.stringify(movie), error => {
      if (error) {
        reject(error);
      } else {
        resolve();
      }
    });
  });
}

function getOne(id) {
  return new Promise((resolve, reject) => {
    client.get(id, (error, data) => {
      if (error) {
        reject(error);
      } else {
        resolve(JSON.parse(data));
      }
    });
  });
}

function remove(id) {
  return new Promise((resolve, reject) => {
    client.del(id, err => {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}

function getAll() {
  return new Promise((resolve, reject) => {
    client.keys('*', (err, keys) => {
      const promises = keys.map(key => getOne(key));
      Promise.all(promises).then(
        values => {
          resolve(values);
        },
        err => reject(err),
      );
    });
  });
}

module.exports = {
  getAll,
  get(id) {
    return getOne(id);
  },
  delete(id) {
    return remove(id);
  },
  save,
};
