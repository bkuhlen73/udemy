const Sequelize = require('sequelize');
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './movie.db',
});

const Movies = sequelize.define(
  'Movies',
  {
    title: {
      type: Sequelize.STRING,
    },
    year: {
      type: Sequelize.INTEGER,
    },
  },
  { timestamps: false },
);

module.exports = {
  getAll() {
    return Movies.findAll();
  },
  get(id) {
    return Movies.findById(id);
  },
  delete(id) {
    return Movies.destroy({ where: { id } });
  },
  save(movie) {
    return Movies.upsert(movie);
  },
};
