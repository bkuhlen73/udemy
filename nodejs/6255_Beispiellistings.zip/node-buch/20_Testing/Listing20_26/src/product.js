function getCategories(data) {
  return ['Schreibmaterial', 'Papier'];
}

module.exports = { getCategories };
