const seneca = require('seneca');

seneca()
  .add({ role: 'user', cmd: 'getAll' }, (msg, respond) => {
    console.log(msg);
    respond(null, { msg: 'All users' });
  })
  .listen();
