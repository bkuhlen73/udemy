const seneca = require('seneca');

seneca()
  .add({ role: 'user', cmd: 'getAll' }, controller.getAllAction)
  .add({ role: 'user', cmd: 'create' }, controller.createAction)
  .listen();
