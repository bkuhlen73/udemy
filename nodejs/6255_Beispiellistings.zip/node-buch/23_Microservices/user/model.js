const MongoClient = require('mongodb').MongoClient;
const url = 'mongodb://localhost:27017';
const dbName = 'users';

async function connect() {
  const client = MongoClient.connect(url);
  const db = client.db(dbName);
  const usersCollection = db.collection('users');
  return {
    client,
    usersCollection,
  };
}

async function getAll() {
  const { client, usersCollection } = await connect();
  const data = await usersCollection.find().toArray();
  client.close();
  return data;
}

async function create(user) {
  const { client, usersCollection } = await connect();
  const result = await usersCollection.insertOne(user);
  client.close();
  return result;
}

module.exports = {
  getAll,
  create,
};
