const model = require('./model');

async function getAllAction(msg, respond) {
  try {
    const allUsers = await model.getAll();
    respond(null, allUsers);
  } catch (e) {
    respond(e);
  }
}

async function createAction(msg, respond) {
  try {
    const user = msg.user;
    const newUser = await model.create(user);
    respond(null, newUser);
  } catch (e) {
    respond(e);
  }
}

module.exports = {
  getAllAction,
  createAction,
};
