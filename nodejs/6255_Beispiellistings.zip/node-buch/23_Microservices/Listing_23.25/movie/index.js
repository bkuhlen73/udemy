const express = require('express');
const bodyParser = require('body-parser');
const controller = require('./controller');

const app = express();
app.use(bodyParser.json());

app.get('/movie', controller.getAllAction);
app.post('/movie', controller.createAction);

app.listen(8181, () => console.log('Movie service is listening'));
