const model = require('./model');

async function getAllAction(request, response) {
  try {
    const movies = await model.getAll();
    response.json(movies);
  } catch (e) {
    response.status(500).json(e);
  }
}
async function createAction(request, response) {
  try {
    const movie = await model.create(request.body);
    response.json(movie);
  } catch (e) {
    response.status(500).json(e);
  }
}

module.exports = {
  getAllAction,
  createAction,
};
