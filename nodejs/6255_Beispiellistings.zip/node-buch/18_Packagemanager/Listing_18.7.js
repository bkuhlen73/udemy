const _ = require('lodash');
const arr1 = ['a', 'b', 'c'];
const arr2 = ['b', 'c', 'd'];
console.log(_.intersection(arr1, arr2));
