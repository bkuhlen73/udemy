const chalk = require('chalk');

console.log(chalk.yellow('gelb'));
console.log(chalk.red('rot'));
console.log(chalk.blue('blau'));
