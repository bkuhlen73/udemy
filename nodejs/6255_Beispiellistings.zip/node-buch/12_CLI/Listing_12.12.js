const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function promisedQuestion(question) {
  return new Promise(resolve => {
    rl.question(question, answer => resolve(answer));
  });
}

const user = {
  name: '',
  city: '',
};

promisedQuestion("What's your name? ")
  .then(name => {
    user.name = name;
    return promisedQuestion('Where do you live? ');
  })
  .then(city => {
    user.city = city;
  })
  .then(() => {
    console.log(`Hello ${user.name} from ${user.city}`);
    process.exit();
  });
