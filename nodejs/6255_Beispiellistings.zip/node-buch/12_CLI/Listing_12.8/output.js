process.stdout.write('This is stdout\n');
process.stderr.write('This is stderr\n');
