console.log('\u001b[33m gelb');
console.log('\u001b[31m rot');
console.log('\u001b[34m blau');
console.log('\u001b[0m');
