const http = require('http');
const url = require('url');

http
  .createServer((req, res) => {
    const reqData = url.parse(req.url, true).query;
    const user = new User(reqData.id);
    const whitelist = ['create', 'read'];

    if (reqData.method && whitelist.indexOf(reqData.method) != -1) {
      res.end(user[reqData.method]());
    } else {
      req.statusCode = 403;
      res.end();
    }
  })
  .listen(8080);
