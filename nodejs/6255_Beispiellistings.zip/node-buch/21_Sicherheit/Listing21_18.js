const http = require('http');
const url = require('url');

class User {
  create() {
    console.log('create');
  }
  read() {
    console.log('read');
  }
  update() {
    console.log('update');
  }
  delete() {
    console.log('delete');
  }
}

http
  .createServer((req, res) => {
    const reqData = url.parse(req.url, true).query;
    const user = new User(reqData.id);

    res.end(user[reqData.method]());
  })
  .listen(8080);
