const http = require('http');
const url = require('url');
const entities = require('entities');

http
  .createServer((req, res) => {
    const input = url.parse(req.url, true).query.input;
    res.end(`<html><body>${entities.encode(input)}</body></html>`);
  })
  .listen(8080);
