const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const csurf = require('csurf');
const exphbs = require('express-handlebars');
const express = require('express');

const csurfFunc = csurf({ cookie: true });
const parseForm = bodyParser.urlencoded({ extended: false });

const app = express();
app.use(cookieParser());
app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');

app.get('/', csurfFunc, (req, res) => {
  res.render('form', { csrfToken: req.csrfToken() });
});

app.post('/form', parseForm, csurfFunc, (req, res) => {
  res.send(`You just bought ${req.body.amount} pieces of ${req.body.article}`);
});
app.listen(8080);
