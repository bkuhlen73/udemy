const http = require('http');
const url = require('url');

http
  .createServer((req, res) => {
    const input = url.parse(req.url, true).query.input;
    res.end(`<html><body>${input}</body></html>`);
  })
  .listen(8080);
