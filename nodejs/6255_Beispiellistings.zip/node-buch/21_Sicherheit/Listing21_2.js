const http = require('http');
const url = require('url');

http
  .createServer((req, res) => {
    const parts = url.parse(req.url, true);
    let name = '';

    if (parts.query.name) {
      name = parts.query.name.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    res.end(`<div>Hello ${name}</div>`);
  })
  .listen(8080);
