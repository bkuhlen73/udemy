const http = require('http');
const mysql = require('mysql');
const url = require('url');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'test',
  multipleStatements: true,
});

http
  .createServer((req, res) => {
    const id = url.parse(req.url, true).query.id;

    if (id != undefined) {
      const sql = 'SELECT * FROM users WHERE id = ' + id;

      connection.query(sql, (err, result) => {
        const data = result[0];
        res.end(`ID: ${data.id} name: ${data.name}`);
      });
    }
  })
  .listen(8080);
