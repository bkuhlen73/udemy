function createGlobal() {
  global.myName = 'Peter';
}

createGlobal();

console.log(myName);
