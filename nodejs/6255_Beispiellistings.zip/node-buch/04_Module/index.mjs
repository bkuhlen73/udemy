import { add } from './Listing4_19';

console.log(add(1, 1));
