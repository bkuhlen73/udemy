export function add(a, b) {
  return a + b;
}

export default function(a, b) {
  return a / b;
}
