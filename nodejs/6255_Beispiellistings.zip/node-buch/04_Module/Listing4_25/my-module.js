module.exports = function() {
  console.log('myModule called');
};
