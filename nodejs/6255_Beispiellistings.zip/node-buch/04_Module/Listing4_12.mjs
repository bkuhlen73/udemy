import divide, { add } from './module';

console.log(divide(4, 2));
console.log(add(2, 2));
