const os = require('os');
console.log(os.uptime());
