const add = require('./Listing1_8');

const result = add(1, 2);
console.log('result: ', result);
