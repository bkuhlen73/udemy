module.exports = {
  add(a, b) {
    return a + b;
  },
};
