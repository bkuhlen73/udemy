declare function add(a: number, b: number): number;
export { add };
