"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.add = function (a, b) { return a + b; };
