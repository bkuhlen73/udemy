import { add } from './module';

console.log(add(1, 2));
