"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var module_1 = require("./module");
console.log(module_1.add(1, 2));
