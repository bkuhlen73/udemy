class Movie {
  public rating: number;
  constructor(public title: string, public year: number) {}
}

function rateMovie(movie: Movie, rating: number) {
  movie.rating = rating;
}

const ironMan: Movie = new Movie('Iron Man', '2008');

rateMovie('Iron Man', 4);
