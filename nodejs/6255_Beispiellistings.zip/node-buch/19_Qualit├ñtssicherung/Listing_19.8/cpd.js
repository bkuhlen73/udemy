function duplicate1(input) {
  let output = '';
  for (let i = 0; i < 10; i++) {
    output += input;
  }
  return output;
}

function duplicate2(input) {
  let output = '';
  for (let i = 0; i < 10; i++) {
    output += input;
  }
  return output;
}
