#!/usr/local/bin/node
console.log('Hello World');
